package goUtils

type World [][]uint8

type Params struct {
	Turns       int
	Threads     int
	ImageWidth  int
	ImageHeight int
}
